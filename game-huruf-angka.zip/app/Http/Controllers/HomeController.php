<?php

namespace App\Http\Controllers;

use App\Models\Angka;
use App\Models\Huruf;
use Illuminate\Http\Request;
use Inertia\Inertia;

class HomeController extends Controller
{
    public function index()
    {
        return Inertia::render('Homepage');
    }

    public function mengenal_huruf()
    {
        $huruf = Huruf::all();
        return Inertia::render('MengenalHuruf', [
            'huruf' => $huruf
        ]);
    }

    public function mengenal_angka()
    {
        $angka = Angka::all();
        return Inertia::render('MengenalAngka', [
            'angka' => $angka
        ]);
    }
}
