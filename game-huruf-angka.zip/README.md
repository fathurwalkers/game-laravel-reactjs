## Game Pengenalan Angka dan Huruf 
<p>
    Ini adalah Game interaktif dengan konsep pengenalan huruf dan angka yang ditujukan untuk anak-anak khusus usia 4 - 6 Tahun
</p>
<p>
    Game ini dibuat menggunakan Fullstack Laravel dan ReactJS serta Menggunakan InertiaJS. 
</p> 
